#ifndef MI_ITEM_H
#define MI_ITEM_H


class Mi_Item
{
public:
    Mi_Item();
};

#endif // MI_ITEM_H
