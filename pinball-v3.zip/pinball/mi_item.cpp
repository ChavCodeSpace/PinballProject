#include "mi_item.h"

Mi_Item::Mi_Item()
{

}
