#include "escena.h"

Escena::Escena(QObject *parent)
    :QGraphicsScene(parent)
{
    mImg = new Canica(":bola1.png");
    mImg->setPos(QPointF(0.0,0.0));
    mImg->setVel(QPoint(1.0,1.0));
    mImg->setSize(QSizeF(20.0,20.0));
    addItem(mImg);
}
