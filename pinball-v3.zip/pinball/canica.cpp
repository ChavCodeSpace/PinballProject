#include "canica.h"

Canica::Canica(const QString &filename, QGraphicsItem *parent) : QGraphicsItem (parent)
{
    mFilename=filename;
}

QPointF Canica::pos() const
{
    return mPos;
}

void Canica::setPos(const QPointF &pos)
{
    mPos = pos;
}

QPointF Canica::vel() const
{
    return mVel;
}

void Canica::setVel(const QPointF &vel)
{
    mVel = vel;
}

QSizeF Canica::size() const
{
    return mSize;
}

void Canica::setSize(const QSizeF &size)
{
    mSize = size;
}

QString Canica::filename() const
{

}

QRectF Canica::boundingRect() const
{
    return QRectF(mPos.x(),mPos.y(),mSize.width(),mSize.height());
}

void Canica::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    painter->drawPixmap(mPos.x(),mPos.y(),mSize.width(),mSize.height(),QPixmap(mFilename));
}
