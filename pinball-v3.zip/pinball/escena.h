#ifndef ESCENA_H
#define ESCENA_H

#include "canica.h"
#include <QGraphicsScene>

class Escena: public QGraphicsScene
{
public:
    Escena(QObject *parent= nullptr);
private:
    Canica *mImg;
};

#endif // ESCENA_H
