#ifndef CANICA_H
#define CANICA_H

#include <QGraphicsItem>
#include <QtCore>
#include <QtGui>
#include <QGraphicsScene>

#include <QPoint>
#include <QPainter>

class Canica: public QGraphicsItem
{
public:
    Canica(const QString &filename, QGraphicsItem *parent=nullptr);
    // Posición
    QPointF pos() const;
    void setPos(const QPointF &pos);
    // Velocidad
    QPointF vel() const;
    void setVel(const QPointF &vel);
    // Tamaño
    QSizeF size() const;
    void setSize(const QSizeF &size);
    // Archivo o imagen
    QString filename() const;

protected:
    QRectF boundingRect() const;

    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget=0);


private:
    QPointF mPos; // posx posy
    QPointF mVel; // vx vy
    QSizeF mSize; // ancho y alto
    QString mFilename; // nombre del archivo o imagen
};

#endif // CANICA_H
