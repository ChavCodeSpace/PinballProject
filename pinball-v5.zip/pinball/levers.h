#ifndef LEVERS_H
#define LEVERS_H

#include <QGraphicsRectItem>
#include <QObject>

class Levers:public QObject, public QGraphicsRectItem
{
    Q_OBJECT
public:
    Levers();
    void keyPressEvent(QKeyEvent * event);
};

#endif // LEVERS_H
