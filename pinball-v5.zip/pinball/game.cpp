#include "game.h"
#include <QTimer>
#include <QGraphicsTextItem>
#include <QFont>

//Medidas de la escena
#define WIDTH 500
#define HEIGHT 700

Game::Game(QWidget *parent){
    // Creando escena
    scene = new QGraphicsScene();
    // Tamaño de la escena
    scene->setSceneRect(0,0,WIDTH,HEIGHT); // make the scene 800x600 instead of infinity by infinity (default)
    // make the newly created scene the scene to visualize (since Game is a QGraphicsView Widget,
    // it can be used to visualize scenes)
    setScene(scene);
    // Desactivar barras de desplazamiento
    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    // Tamaño fijo
    setFixedSize(WIDTH,HEIGHT);

    // Dibujar bordes de la escena
    QPen mypen = QPen(Qt::red);
    mypen.setWidth(10);
    QLineF TopLine(scene->sceneRect().topLeft(), scene->sceneRect().topRight());
    QLineF LeftLine(scene->sceneRect().topLeft(), scene->sceneRect().bottomLeft());
    QLineF RightLine(scene->sceneRect().topRight(), scene->sceneRect().bottomRight());
    QLineF BottomLine(scene->sceneRect().bottomLeft(), scene->sceneRect().bottomRight());
    scene->addLine(TopLine,mypen);
    scene->addLine(LeftLine,mypen);
    scene->addLine(RightLine,mypen);
    scene->addLine(BottomLine,mypen);

    // Crear bola
    ball = new Ball();
    scene->addItem(ball);

    // Crear palanca izquierda
    left_lever= new Levers();
    left_lever->setRect(0,0,70,15);
    left_lever->setPos(WIDTH/4,HEIGHT-100);
    scene->addItem(left_lever);

    left_lever->setFlag(QGraphicsItem::ItemIsFocusable);
    left_lever->setFocus();

    // Crear palanca derecha
    right_lever= new Levers();
    right_lever->setRect(0,0,70,15);
    right_lever->setPos(WIDTH-WIDTH/4,HEIGHT-100);
    scene->addItem(right_lever);
    //right_lever->setRotation(-15);

/*
    QGraphicsRectItem *rect=new QGraphicsRectItem();
    rect->setRect(0,0,70,15);
    scene->addItem(rect);
    rect->setPos(100,100);

    QGraphicsRectItem *rect2=new QGraphicsRectItem();
    rect2->setRect(0,0,70,15);
    scene->addItem(rect2);
    rect2->setPos(100,100);
    // Primera opción
    //rect2->setRotation(15);
    // Segunda opción
    QTransform t;
    t.rotate(-15);
    rect2->setTransform(t);
*/

    show();
}
