#ifndef BALL_H
#define BALL_H

#include <QGraphicsEllipseItem>
#include <QObject>
#include <QTimer>


class Ball: public QObject,public QGraphicsEllipseItem
{
    Q_OBJECT
public:
    Ball();
public slots:
    void move();
private:
    int delta_x;
    int delta_y;
};

#endif // BALL_H
