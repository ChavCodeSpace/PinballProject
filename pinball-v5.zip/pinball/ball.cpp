#include "ball.h"
#include <QTimer>
#include <QGraphicsScene>
#include <QDebug>
#include "game.h"

//Medidas de la escena
#define WIDTH 500.0
#define HEIGHT 700.0

Ball::Ball():QObject()
{
    delta_x=10;
    delta_y=10;
    setRect(0,0,25,25);
    setPos(100,100);
    //Conectar
    QTimer * timer = new QTimer();
    connect(timer,SIGNAL(timeout()),this,SLOT(move()));
    timer->start(50);
}

void Ball::move()
{

    /*if (pos().y() + rect().height() > 600){
        scene()->removeItem(this);
        delete this;
        qDebug()<<"Se elimino la bola";
    }*/

    if(scene()->collidingItems(this).isEmpty())
    {
        //No hay colisión entonces seguir su movimiento normal
        setPos(x()+delta_x,y()+delta_y);
    }
    else
    {
        if((pos().x()== WIDTH || pos().x()==0.0) && (pos().y()== HEIGHT|| pos().y()==0.0)){
            delta_x=-1*delta_x;
            delta_y=-1*delta_y;
        }
        else if(pos().x()== WIDTH || pos().x()==0.0){
            delta_x=-1*delta_x;
        }
        else if (pos().y()== HEIGHT|| pos().y()==0.0) {
            delta_y=-1*delta_y;
        }
        setPos(x()+delta_x,y()+delta_y);
    }

}
