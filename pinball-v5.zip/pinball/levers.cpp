#include "levers.h"
#include <QGraphicsScene>
#include <QKeyEvent>
#include <QtDebug>
#include <QGraphicsItem>
#include <QTransform>
#include <QGraphicsView>

Levers::Levers()
{

}

void Levers::keyPressEvent(QKeyEvent *event)
{
    if (event->key() == Qt::Key_Left){
        setRotation(-15);
        qDebug()<<"izquierdo";
    }
    else if (event->key() == Qt::Key_Right){
        setRotation(15);
        qDebug()<<"Derecho";
    }
}
