#include "levers.h"
#include <QGraphicsScene>
#include <QtDebug>
#include <QGraphicsItem>
#include <QTransform>
#include <QGraphicsView>

Levers::Levers()
{
    qDebug()<<"Se creo una palanca";
    setPos(0,0);
}
